package practicas_eldom.config;

public class MB_Registers {
	
	//Discrete Output Coils
	public static final int MB_RELE 	= 0;
	public static final int MB_TRIAC	= 1;
	public static final int MB_O_COILS	= 2;
	
	
}
