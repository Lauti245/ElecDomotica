package practicas_eldom.messages;

public class Messages {
	public final static String	ARCHIVO 		= "Fichero";
	public final static String	COMUNICACIONES 	= "Comunicaciones";
	public final static String	SERIE 			= "Serie";
	public final static String	SALIR 			= "Salir";
	public final static String	CONSOLE 		= "Monitor";
	
	public final static String	LOOKPORTS 		= "Buscando nuevos puertos serie";
	
	public final static String	OPT_SERIE 		= "Opciones Conexi�n Serie";
	
	public final static String	PORTSELTOCOMM 	= "Puerto seleccionado para comunicaciones: " ;
	
}
